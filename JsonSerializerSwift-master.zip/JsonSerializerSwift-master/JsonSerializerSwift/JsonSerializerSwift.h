//
//  JsonSerializerSwift.h
//  JsonSerializerSwift
//
//  Created by Peter Helstrup Jensen on 13/10/2015.
//  Copyright © 2015 Peter Helstrup Jensen. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JsonSerializerSwift.
FOUNDATION_EXPORT double JsonSerializerSwiftVersionNumber;

//! Project version string for JsonSerializerSwift.
FOUNDATION_EXPORT const unsigned char JsonSerializerSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JsonSerializerSwift/PublicHeader.h>


