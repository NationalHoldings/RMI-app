# Glowing-UIButton
Sample app that uses a custom UIButton class that adds a glowing effect.   
XCode 6.3 / Swift 1.2
